import 'package:meta/meta.dart';

class AccelerometerLogs {
  final double x;
  final double y;
  final double z;

  AccelerometerLogs({
    @required this.x,
    @required this.y,
    @required this.z,
  });
}
