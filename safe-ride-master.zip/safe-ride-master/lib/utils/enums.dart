enum UserType { driver, passanger }
enum AppBarBehavior { normal, pinned, floating, snapping }
